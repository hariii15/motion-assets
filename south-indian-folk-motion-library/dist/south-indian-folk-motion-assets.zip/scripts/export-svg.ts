import {mkdirSync,writeFileSync} from 'node:fs';
import {assets} from '../src/catalog';
import {renderSvg} from '../src/components/Asset';
mkdirSync('exports/svg',{recursive:true});
for(const a of assets)writeFileSync(`exports/svg/${a.id}.svg`,renderSvg({id:a.id,static:true}));
console.log(`SVG: ${assets.length}`);
