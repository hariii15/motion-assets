import {existsSync,readFileSync,statSync,readdirSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import sharp from 'sharp';
import assert from 'node:assert/strict';
import {assets} from '../src/catalog';
import {renderSvg} from '../src/components/Asset';
const report:any={assets:assets.length,svg:0,png:0,webm:0,lottie:0,checks:[]};
const file=(p:string)=>{assert(!p.includes('..')&&!p.startsWith('/'),'Unsupported path '+p);assert(existsSync(p),'Missing '+p);assert(statSync(p).size>0,'Empty '+p);return readFileSync(p);};
const run=(cmd:string,args:string[])=>{const r=spawnSync(cmd,args,{maxBuffer:20*1024*1024});assert.equal(r.status,0,r.stderr.toString());return r.stdout;};
const validateWebm=(p:string)=>{
 file(p);const probe=JSON.parse(run('ffprobe',['-v','error','-show_streams','-show_format','-of','json',p]).toString());const s=probe.streams[0];assert.equal(s.codec_name,'vp9');assert.equal((s.tags.alpha_mode??s.tags.ALPHA_MODE),'1');assert.equal(s.r_frame_rate,'30/1');assert.equal(s.width,512);assert.equal(s.height,512);assert(Math.abs(Number(probe.format.duration)-3)<.05);
 const rgba=run('ffmpeg',['-v','error','-c:v','libvpx-vp9','-i',p,'-vf','scale=64:64','-f','rawvideo','-pix_fmt','rgba','pipe:1']);assert.equal(rgba.length,90*64*64*4,'Incomplete decoded alpha video');assert(!rgba.subarray(0,16384).equals(rgba.subarray(35*16384,36*16384)),'Frozen WebM '+p);const mid=rgba.subarray(45*16384,46*16384);let min=255,max=0;for(let i=3;i<mid.length;i+=4){min=Math.min(min,mid[i]);max=Math.max(max,mid[i]);}assert.equal(min,0,'WebM missing transparent pixels');assert(max>15,'WebM empty');
 const count=Number(run('ffprobe',['-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=nb_read_frames','-of','csv=p=0',p]).toString().trim());assert.equal(count,90,'Truncated WebM');report.webm++;
};
assert.equal(new Set(assets.map(a=>a.id)).size,assets.length,'Duplicate asset IDs');
for(const p of readdirSync('manifests'))if(p.endsWith('.json'))JSON.parse(file('manifests/'+p).toString());
for(const a of assets){
 assert(/^[a-z0-9-]+$/.test(a.filename),'Unsafe filename');assert.equal(a.filename,a.id);
 assert(a.animationPreset&&a.durationInFrames>0&&a.fps===30);for(const id of a.compatibleAssets)assert(assets.some(a=>a.id===id));
 const svg=file(`exports/svg/${a.id}.svg`).toString();assert(svg.includes('viewBox="0 0 1000 1000"'),'Missing viewBox');assert(!svg.includes('NaN')&&!svg.includes('undefined'),'Invalid SVG numeric field');
 run('python',['-c',`import sys,xml.etree.ElementTree as E\nr=E.parse(sys.argv[1]).getroot()\nassert r.tag=='{http://www.w3.org/2000/svg}svg'\nids=[e.attrib['id'] for e in r.iter() if 'id' in e.attrib]\nassert len(ids)==len(set(ids))`, `exports/svg/${a.id}.svg`]);
 const meta=await sharp(file(`exports/png/${a.id}.png`)).metadata();assert.equal(meta.width,1024);assert.equal(meta.height,1024);assert(meta.hasAlpha,'PNG alpha missing');
 const {data}=await sharp(Buffer.from(svg)).resize(256,256).ensureAlpha().raw().toBuffer({resolveWithObject:true});let opaque=0,clear=0;for(let i=3;i<data.length;i+=4){if(data[i]>0)opaque++;if(data[i]===0)clear++;}assert(opaque>5&&clear>1024,'Empty asset or opaque SVG background '+a.id);assert.equal(data[3],0,'Opaque corner');
 // Remove deliberate viewport masks before testing geometry beyond the canvas.
 for(const progress of [0,.25,.5,.75,1]){const expanded=renderSvg({id:a.id,progress}).replace('viewBox="0 0 1000 1000"','viewBox="-100 -100 1200 1200"').replace(/ mask="[^"]*"/g,'').replace(/ clip-path="[^"]*"/g,'');const raw=await sharp(Buffer.from(expanded)).resize(300,300).ensureAlpha().raw().toBuffer();let spill=0;for(let y=0;y<300;y++)for(let x=0;x<300;x++)if((x<25||x>=275||y<25||y>=275)&&raw[(y*300+x)*4+3]>8)spill++;assert.equal(spill,0,`Clipping ${a.id} at ${progress}`);}
 report.svg++;report.png++;
 for(const format of a.animatedFormats){if(format==='webm'){
 validateWebm(`exports/webm/${a.id}.webm`);
 }else if(format==='lottie'){const j=JSON.parse(file(`exports/lottie/${a.id}.json`).toString());assert(a.lottieCompatible&&j.layers.length&&j.fr===30&&j.op===90);report.lottie++;}else throw Error('Unsupported format '+format);}
 for(const extra of (a as typeof a & {additionalAnimatedFiles?:{filename:string}[]}).additionalAnimatedFiles??[])validateWebm('exports/webm/'+extra.filename);
 // Animation must change a rendered frame. Blank first frames are allowed on reveals.
 const frame0=await sharp(Buffer.from(renderSvg({id:a.id,progress:0}))).resize(128).png().toBuffer();let changed=false;for(const progress of [.137,.391,.617,.83,1]){const sample=await sharp(Buffer.from(renderSvg({id:a.id,progress}))).resize(128).png().toBuffer();if(!frame0.equals(sample))changed=true;}assert(changed,'No animation '+a.id);
 if(a.loop){const last=await sharp(Buffer.from(renderSvg({id:a.id,progress:1}))).resize(128).png().toBuffer();assert(frame0.equals(last),'Loop seam '+a.id);}
}
file('exports/catalog/index.html');for(const p of ['asset-catalog.mp4','motion-gallery.mp4','layered-demo.mp4']){const path='exports/previews/'+p;file(path);const d=JSON.parse(run('ffprobe',['-v','error','-show_format','-of','json',path]).toString());assert(Number(d.format.duration)>1);}
const browser=JSON.parse(file('exports/previews/browser-validation.json').toString());assert.equal(browser.lottie.length,9);
assert.equal(readdirSync('exports/webm').filter(f=>f.endsWith('.webm')).length,report.webm,'Unmanifested WebM');
report.checks=['XML parse and unique IDs','viewBox and transparent alpha','1024px PNGs','geometry overflow at five motion samples','meaningful motion and seamless loops','VP9 alpha decoded via libvpx, 90 frames each','catalog browser filters and image loading','Lottie browser render compared with SVG','all three Remotion preview videos'];report.result='PASS';
assert.equal(readdirSync('exports/svg').filter(f=>f.endsWith('.svg')).length,report.svg);assert.equal(readdirSync('exports/png').filter(f=>f.endsWith('.png')).length,report.png);
writeFileSync('exports/previews/validation-report.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
