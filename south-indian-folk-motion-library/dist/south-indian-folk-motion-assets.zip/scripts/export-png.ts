import sharp from 'sharp';
import {mkdirSync,existsSync} from 'node:fs';
import {assets} from '../src/catalog';
import {renderSvg} from '../src/components/Asset';
const preview=process.argv.includes('--draft');const size=preview?256:1024;
mkdirSync('exports/previews',{recursive:true});
for(const a of assets){const out=preview?`exports/previews/${a.id}.png`:`exports/png/${a.id}.png`;if(!existsSync(out))await sharp(Buffer.from(renderSvg({id:a.id,static:true}))).resize(size,size).png().toFile(out);}
if(preview){const cells=await Promise.all(assets.map(async(a,i)=>({input:await sharp(`exports/previews/${a.id}.png`).resize(140).extend({top:10,bottom:35,left:10,right:10,background:'#F0D9A4'}).composite([{input:Buffer.from(`<svg width="160" height="25"><text x="80" y="15" text-anchor="middle" font-family="sans-serif" font-size="8" fill="#24305E">${a.id}</text></svg>`),top:155,left:0}]).png().toBuffer(),left:(i%8)*160,top:Math.floor(i/8)*185})));await sharp({create:{width:1280,height:Math.ceil(assets.length/8)*185,channels:4,background:'#F0D9A4'}}).composite(cells).png().toFile('exports/previews/contact-sheet.png');}
console.log(`PNG: ${assets.length} at ${size}`);
