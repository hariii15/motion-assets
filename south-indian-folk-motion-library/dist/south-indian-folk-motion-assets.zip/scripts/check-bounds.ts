import sharp from 'sharp';
import {assets} from '../src/catalog';
import {renderSvg} from '../src/components/Asset';
let failures=0;
for(const a of assets){for(const progress of [0,.25,.5,.75,1]){const svg=renderSvg({id:a.id,progress}).replace('viewBox="0 0 1000 1000"','viewBox="-100 -100 1200 1200"').replace(/ mask="[^"]*"/g,'').replace(/ clip-path="[^"]*"/g,'');const {data,info}=await sharp(Buffer.from(svg)).resize(300,300).ensureAlpha().raw().toBuffer({resolveWithObject:true});let out=0;for(let y=0;y<300;y++)for(let x=0;x<300;x++)if((x<25||x>=275||y<25||y>=275)&&data[(y*300+x)*4+3]>8)out++;if(out){console.log(a.id,progress,out);failures++;break;}}}
console.log('out-of-bounds assets:',failures);process.exitCode=failures?1:0;
