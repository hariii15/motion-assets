import {spawn} from 'node:child_process';
import {mkdirSync,existsSync,readFileSync,writeFileSync,renameSync} from 'node:fs';
import {once} from 'node:events';
import sharp from 'sharp';
import {assets} from '../src/catalog';
import {renderSvg} from '../src/components/Asset';
const draft=process.argv.includes('--draft');
mkdirSync('exports/previews',{recursive:true});
const targets=assets.filter(a=>a.animatedFormats.includes('webm')).flatMap(a=>[a,...(['kolam-single-line-loop-01','kolam-circular-frame','kolam-mandala'].includes(a.id)?[{...a,filename:a.id+'-one-shot',loop:false}]:[])]);
for(const a of targets){
 const size=draft?192:512,frames=draft?18:a.durationInFrames,fps=draft?6:30;
 const file=`exports/${draft?'previews':'webm'}/${a.filename}.webm`;
 if(existsSync(file))continue;
 const temp=file+'.partial.webm';
 const ff=spawn('ffmpeg',['-hide_banner','-loglevel','error','-y','-f','image2pipe','-framerate',String(fps),'-i','pipe:0','-an','-c:v','libvpx-vp9','-pix_fmt','yuva420p','-auto-alt-ref','0','-b:v','0','-crf','32','-deadline','good','-cpu-used','4','-threads','2','-metadata:s:v:0','alpha_mode=1',temp],{stdio:['pipe','ignore','pipe']});
 let error='';ff.stderr.on('data',d=>error+=d);const done=new Promise<number|null>((resolve,reject)=>{ff.on('error',reject);ff.on('exit',resolve)});
 for(let f=0;f<frames;f++){const frame=f*(a.durationInFrames-1)/(frames-1);const png=await sharp(Buffer.from(renderSvg({id:a.id,frame,loop:a.loop}))).resize(size,size).png().toBuffer();if(!ff.stdin.write(png))await once(ff.stdin,'drain');}
 ff.stdin.end();if(await done!==0)throw new Error(a.id+': '+error);renameSync(temp,file);console.log(`${draft?'draft':'VP9 alpha'}: ${a.id}`);
}
