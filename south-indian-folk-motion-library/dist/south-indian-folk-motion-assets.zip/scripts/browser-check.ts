import {spawn} from 'node:child_process';
import {createServer} from 'node:http';
import {resolve,extname} from 'node:path';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {assets} from '../src/catalog';
import {renderSvg} from '../src/components/Asset';
import sharp from 'sharp';
const sleep=(ms:number)=>new Promise(r=>setTimeout(r,ms));
const root=process.cwd();const server=createServer((req,res)=>{try{const p=resolve(root,'.'+decodeURIComponent((req.url??'/').split('?')[0]));if(!p.startsWith(root+'/')){res.writeHead(403).end();return;}const types:Record<string,string>={'.html':'text/html','.png':'image/png','.svg':'image/svg+xml','.webm':'video/webm','.json':'application/json'};res.setHeader('Content-Type',types[extname(p)]??'application/octet-stream');res.end(readFileSync(p));}catch{res.writeHead(404).end();}});await new Promise<void>(r=>server.listen(8333,'127.0.0.1',r));
const proc=spawn('/usr/bin/chromium',['--headless','--no-sandbox','--disable-dev-shm-usage','--remote-debugging-port=9333','--user-data-dir=/tmp/folk-catalog-browser','about:blank'],{stdio:'ignore'});
let ws:WebSocket|undefined;
try{
 let pages:any[]=[];for(let i=0;i<60;i++){try{pages=await(await fetch('http://127.0.0.1:9333/json')).json();if(pages.length)break;}catch{}await sleep(200);}
 if(!pages.length)throw Error('Chromium CDP startup failed');
 ws=new WebSocket(pages[0].webSocketDebuggerUrl);await new Promise<void>(r=>ws!.addEventListener('open',()=>r(),{once:true}));let id=0;const pending=new Map<number,{resolve:(v:any)=>void,reject:(v:any)=>void}>();ws.addEventListener('message',e=>{const o=JSON.parse(String(e.data));if(o.id){const p=pending.get(o.id)!;pending.delete(o.id);o.error?p.reject(o.error):p.resolve(o.result);}});
 const send=(method:string,params:any={})=>new Promise<any>((resolve,reject)=>{const n=++id;pending.set(n,{resolve,reject});ws!.send(JSON.stringify({id:n,method,params}));});
 const evaluate=async(expression:string)=>{const r=await send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};
 await send('Emulation.setDeviceMetricsOverride',{width:1440,height:1100,deviceScaleFactor:1,mobile:false});
 const nav=await send('Page.navigate',{url:'http://127.0.0.1:8333/exports/catalog/index.html'});if(nav.errorText)throw Error('Catalog navigation: '+JSON.stringify(nav));
 for(let i=0;i<50;i++){if(await evaluate('window.catalogReady===true'))break;await sleep(100);}
 const count=await evaluate('document.querySelectorAll("article").length');if(count!==102)throw Error('Catalog card count '+count);
 const formatCount=await evaluate(`document.querySelector('#formats').value='webm';document.querySelector('#formats').dispatchEvent(new Event('change'));document.querySelectorAll('article:not([hidden])').length`);if(formatCount!==20)throw Error('Catalog WebM filter '+formatCount);
 const categoryCount=await evaluate(`document.querySelector('#formats').value='';document.querySelector('#category').value='kolam';document.querySelector('#category').dispatchEvent(new Event('change'));document.querySelectorAll('article:not([hidden])').length`);if(categoryCount!==10)throw Error('Category filter failed');
 const filterChecks=await evaluate(`(()=>{const counts={};for(const [key,value] of [['animated','animated'],['animated','static'],['loop','loop'],['loop','one-shot'],['beat','ambient'],['beat','beat-reactive'],['formats','lottie']]){document.querySelectorAll('select').forEach(s=>s.value='');document.getElementById(key).value=value;filter();counts[key+':'+value]=document.querySelectorAll('article:not([hidden])').length;}document.querySelectorAll('select').forEach(s=>s.value='');document.querySelector('#search').value='jasmine';filter();counts.search=document.querySelectorAll('article:not([hidden])').length;document.querySelector('#search').value='';filter();return counts;})()`);
 if(filterChecks['formats:lottie']!==3||filterChecks.search!==1||filterChecks['animated:animated']!==22||filterChecks['animated:static']!==80)throw Error('Catalog filter counts '+JSON.stringify(filterChecks));
 await evaluate(`document.querySelector('#category').value='';filter();document.querySelectorAll('img').forEach(i=>i.loading='eager');Promise.all([...document.images].map(i=>i.decode()))`);
 const missing=await evaluate('[...document.images].filter(i=>!i.naturalWidth).length');if(missing)throw Error('Broken catalog images '+missing);
 await send('Page.captureScreenshot',{format:'png'}).then(r=>writeFileSync('exports/previews/catalog-browser.png',Buffer.from(r.data,'base64')));
 const pdf=await send('Page.printToPDF',{printBackground:true,paperWidth:8.27,paperHeight:11.69,marginTop:.3,marginBottom:.3,marginLeft:.3,marginRight:.3});writeFileSync('exports/catalog/catalog.pdf',Buffer.from(pdf.data,'base64'));
 await send('Page.navigate',{url:'about:blank'});await sleep(150);
 await send('Emulation.setDeviceMetricsOverride',{width:1000,height:1000,deviceScaleFactor:1,mobile:false});
 await send('Emulation.setDefaultBackgroundColorOverride',{color:{r:0,g:0,b:0,a:0}});
 await evaluate(`document.body.style.margin='0';document.body.innerHTML='<div id="player" style="width:1000px;height:1000px"></div>'`);
 await evaluate(readFileSync('node_modules/lottie-web/build/player/lottie.min.js','utf8'));
 const results:any[]=[];
 for(const a of assets.filter(a=>a.lottieCompatible)){
 const data=readFileSync('exports/lottie/'+a.id+'.json','utf8');
 await evaluate(`window.anim&&window.anim.destroy();window.anim=lottie.loadAnimation({container:document.querySelector('#player'),renderer:'svg',loop:true,autoplay:false,animationData:${data}});new Promise(r=>window.anim.addEventListener('DOMLoaded',r))`);
 for(const frame of [0,45,89]){
 await evaluate(`anim.goToAndStop(${frame},true)`);
 const shot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});const png=Buffer.from(shot.data,'base64');
 const rendered=await sharp(png).ensureAlpha().raw().toBuffer();
 const expected=await sharp(Buffer.from(renderSvg({id:a.id,frame}))).resize(1000,1000).ensureAlpha().raw().toBuffer();
 let err=0;for(let i=3;i<rendered.length;i+=4)err+=Math.abs(rendered[i]-expected[i]);err/=1000000;
 if(err>1.5)throw Error(`Lottie alpha mismatch ${a.id} frame ${frame}: ${err}`);results.push({id:a.id,frame,meanAlphaError:err});
 }
 }
 writeFileSync('exports/previews/browser-validation.json',JSON.stringify({catalog:{cards:count,webmFiltered:formatCount,kolamFiltered:categoryCount,brokenImages:missing,filters:filterChecks},lottie:results,pdf:true},null,2));
 console.log('Browser: catalog filters, all images, PDF, and 9 Lottie frame comparisons passed');
}finally{ws?.close();proc.kill('SIGTERM');server.close();}
