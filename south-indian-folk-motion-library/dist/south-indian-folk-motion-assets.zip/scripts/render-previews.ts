import {spawnSync} from 'node:child_process';
import {existsSync,mkdirSync,writeFileSync} from 'node:fs';
mkdirSync('.scratch',{recursive:true});
for(const [id,out,scale] of [['AssetCatalogComposition','asset-catalog',.5],['MotionGalleryComposition','motion-gallery',.5],['LayeredDemoComposition','layered-demo',1]] as const){
 const file=`exports/previews/${out}.mp4`;if(existsSync(file))continue;
 const browser=process.env.CHROMIUM_PATH??'/usr/bin/chromium';
 const r=spawnSync('npx',['remotion','render','src/demo/index.ts',id,file,`--browser-executable=${browser}`,`--scale=${scale}`,'--concurrency=2','--log=error'],{encoding:'utf8',maxBuffer:20*1024*1024});writeFileSync(`.scratch/${out}.log`,r.stdout+r.stderr);if(r.status!==0)throw Error(r.stderr+' (see .scratch/'+out+'.log)');console.log('Rendered '+id);
}
