import {writeFileSync} from 'node:fs';
import {assets} from '../src/catalog';
import {motion} from '../src/animation';
for(const a of assets.filter(a=>a.lottieCompatible)){
 const key=(fn:(p:number)=>number[])=>({a:1,k:Array.from({length:90},(_,f)=>({t:f,s:fn(f/89),e:fn(Math.min(89,f+1)/89),o:{x:.333,y:.333},i:{x:.667,y:.667}}))});
 const col=(h:string)=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)/255).concat(1);
 const data={v:'5.7.4',fr:30,ip:0,op:90,w:1000,h:1000,nm:a.id,ddd:0,assets:[],layers:[{ddd:0,ind:1,ty:4,nm:a.id,sr:1,ks:{o:key(p=>[motion(a.animationPreset,p,true).opacity*100]),r:{a:0,k:0},p:{a:0,k:[500,500,0]},a:{a:0,k:[500,500,0]},s:key(p=>{const s=motion(a.animationPreset,p,true).scale*100;return[s,s,100]})},ao:0,shapes:[0,1,2].map(i=>({ty:'gr',nm:'ring '+i,it:[{ty:'el',p:{a:0,k:[500,500]},s:{a:0,k:[340+i*130,340+i*130]},d:1,nm:'ellipse'},{ty:'st',c:{a:0,k:col(a.palette[i%2])},o:{a:0,k:100},w:{a:0,k:6-i},lc:1,lj:1,nm:'stroke'},{ty:'tr',p:{a:0,k:[0,0]},a:{a:0,k:[0,0]},s:{a:0,k:[100,100]},r:{a:0,k:0},o:{a:0,k:100},sk:{a:0,k:0},sa:{a:0,k:0}}]})),ip:0,op:90,st:0,bm:0}]};
 writeFileSync(`exports/lottie/${a.id}.json`,JSON.stringify(data));
}
console.log('Lottie: 3 exact ellipse/transform animations');
