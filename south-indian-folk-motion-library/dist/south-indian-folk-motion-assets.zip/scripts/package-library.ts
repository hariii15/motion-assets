import {spawnSync} from 'node:child_process';
import {mkdirSync,rmSync,statSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
const validate=spawnSync('npx',['tsx','scripts/validate-assets.ts'],{stdio:'inherit'});if(validate.status!==0)process.exit(validate.status??1);
mkdirSync('dist',{recursive:true});const zip='dist/south-indian-folk-motion-assets.zip';rmSync(zip,{force:true});
const r=spawnSync('zip',['-q','-r',zip,'exports/svg','exports/png','exports/webm','exports/lottie','exports/catalog','exports/previews','manifests','src','scripts','README.md','LICENSE-ASSETS.md','package.json','package-lock.json','tsconfig.json','-x','*.partial.webm','*.map','*/.DS_Store'],{stdio:'inherit'});if(r.status!==0)throw Error('ZIP failed');
const check=spawnSync('unzip',['-tqq',zip],{stdio:'inherit'});if(check.status!==0)throw Error('ZIP integrity failed');
const sha=createHash('sha256').update(readFileSync(zip)).digest('hex');writeFileSync(zip+'.sha256',sha+'  south-indian-folk-motion-assets.zip\n');console.log(`ZIP verified: ${zip} (${statSync(zip).size} bytes)`);
