export const colors = {vermilion:'#C9342F',turmeric:'#E4A928',indigo:'#24305E',teal:'#13706D',green:'#557A45',pink:'#D95B82',cream:'#F0D9A4',gold:'#D6A63A',ink:'#2A211C'} as const;
export const palettes = {ceremony:[colors.vermilion,colors.gold,colors.indigo,colors.cream],garden:[colors.teal,colors.pink,colors.gold,colors.cream],manuscript:[colors.ink,colors.gold,colors.green,colors.cream]};
