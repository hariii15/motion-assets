import data from '../../manifests/assets.json';
export type AssetRecord=Omit<typeof data[number], 'animatedFormats'|'staticFormats'|'webmSettings'> & {animatedFormats:string[];staticFormats:string[];additionalAnimatedFiles?:{format:string;filename:string;loop:boolean;durationInFrames:number}[];webmSettings:{width:number;height:number;codec:string;pixelFormat:string;alpha:boolean;versions:string[]}|null};
export const assets:AssetRecord[]=data as AssetRecord[];
export const getAsset=(id:string)=>{const a=assets.find(a=>a.id===id);if(!a)throw new Error('Unknown asset: '+id);return a;};
