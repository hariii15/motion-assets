import React from 'react';
import {useCurrentFrame,useVideoConfig} from 'remotion';
import {getAsset} from '../catalog';
import {makeBody,type GeneratorProps,type GeneratorName} from '../generators';
import {motion,intensities} from '../animation';
import {clamp} from '../utils/random';
export type AssetProps=Partial<GeneratorProps>&{id:string;frame?:number;intensityName?:keyof typeof intensities;static?:boolean;animationPreset?:string;instanceId?:string};
export function svgInner(props:AssetProps):string{
 const a=getAsset(props.id),duration=props.durationInFrames??a.durationInFrames,loop=props.loop??a.loop;
 const p=props.static?1:props.progress??clamp((loop?((props.frame??0)%duration):(props.frame??0))/Math.max(1,duration-1));
 const power=props.intensity??intensities[props.intensityName??a.recommendedBeatType as keyof typeof intensities]??.5;
 const m=props.static?{x:0,y:0,scale:1,rotate:0,opacity:1,reveal:1,draw:1}:motion(props.animationPreset??a.animationPreset,p,loop,power,props.beatStrength??0);
 const token=(props.instanceId??a.id).replace(/[^\w-]/g,'');
 const [primaryColor,secondaryColor,accentColor]=a.palette;
 const body=makeBody(a.generator as GeneratorName,{primaryColor,secondaryColor,accentColor,...props,variant:props.variant??a.variant,progress:p,seed:props.seed??a.seed,loop,intensity:power});
 const zones=props.exclusionZones??[];
 const dir=props.direction??(a.id==='kolam-border-vertical'?'down':'right');
 const reveal=dir==='left'?`x="${1000*(1-m.reveal)}" y="0" width="${1000*m.reveal}" height="1000"`:dir==='up'?`x="0" y="${1000*(1-m.reveal)}" width="1000" height="${1000*m.reveal}"`:dir==='down'?`x="0" y="0" width="1000" height="${1000*m.reveal}"`:`x="0" y="0" width="${1000*m.reveal}" height="1000"`;
 const scale=(props.scale??1)*m.scale;
 const glow=Math.max(0,Math.min(1,props.glowAmount??0));
 return `<defs><mask id="${token}-zones" maskUnits="userSpaceOnUse" x="0" y="0" width="1000" height="1000"><rect width="1000" height="1000" fill="white"/>${zones.map(z=>`<rect x="${z.x}" y="${z.y}" width="${z.width}" height="${z.height}" fill="black"/>`).join('')}</mask><clipPath id="${token}-reveal"><rect ${reveal}/></clipPath><filter id="${token}-glow" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="${glow*5}"/></filter></defs><g mask="url(#${token}-zones)" clip-path="url(#${token}-reveal)"><g transform="translate(${m.x} ${m.y}) translate(500 500) rotate(${(props.rotation??0)+m.rotate+(props.swayAmount??0)*Math.sin(p*Math.PI*2)}) scale(${scale}) translate(-500 -500)" opacity="${m.opacity*(props.opacity??1)}" fill="none" color="${props.primaryColor??primaryColor}" stroke-width="${props.strokeWidth??5}" ${m.draw<1?`stroke-dasharray="${Math.max(.01,m.draw)*1800} 2400"`:''}>${glow?`<g opacity="${glow*.3}" filter="url(#${token}-glow)">${body}</g>`:''}${body}</g></g>`;
}
export function renderSvg(props:AssetProps){return `<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="0 0 1000 1000">${svgInner(props)}</svg>`;}
export const Asset:React.FC<AssetProps>=(props)=>{const instanceId=React.useId();return <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000" style={{width:'100%',height:'100%',overflow:'hidden'}} dangerouslySetInnerHTML={{__html:svgInner({...props,instanceId:props.instanceId??instanceId})}}/>;};
export const RemotionAsset:React.FC<Omit<AssetProps,'frame'>>=(props)=>{const frame=useCurrentFrame(),{durationInFrames}=useVideoConfig();return <Asset {...props} frame={frame} durationInFrames={props.durationInFrames??durationInFrames}/>;};
