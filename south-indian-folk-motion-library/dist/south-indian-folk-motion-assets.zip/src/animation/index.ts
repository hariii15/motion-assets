import {ease} from '../utils/random';
export const intensities={'ambient':.25,'secondary beat':.5,downbeat:.75,transition:1} as const;
export type Motion={x:number;y:number;scale:number;rotate:number;opacity:number;reveal:number;draw:number};
export function motion(preset:string,p:number,loop:boolean,power=.5,beat=0):Motion{
 const q=ease(p),s=Math.sin(p*Math.PI*2),pulse=(1-Math.cos(p*Math.PI*2))/2;
 const m:Motion={x:0,y:0,scale:1,rotate:0,opacity:1,reveal:1,draw:1};
 switch(preset){
 case 'draw-on':m.draw=loop?.08+.92*pulse:q;m.reveal=m.draw;break;
 case 'hand-painted reveal':m.reveal=q;break;
 case 'block-print stamp':m.scale=.88+.12*ease(Math.min(1,p*4));m.opacity=ease(Math.min(1,p*5));break;
 case 'lamp ignition':m.opacity=.15+.85*q;break;
 case 'flame flicker':m.scale=1+Math.sin(p*Math.PI*6)*.012*power;break;
 case 'halo breathing':m.scale=1+.035*power*s;m.opacity=.83+.17*pulse;break;
 case 'aura expansion':case 'pulse-ring expansion':m.scale=.82+.18*pulse;m.opacity=1-.25*pulse;break;
 case 'lotus bloom':m.scale=.78+.22*q;break;
 case 'garland sway':m.rotate=s*2*power;break;
 case 'bell swing':break;
 case 'petal burst':m.scale=.3+.7*q;m.opacity=1-.5*q;break;
 case 'petal drift':m.y=s*12*power;m.rotate=s*1.5*power;break;
 case 'incense rise':m.y=-12*pulse*power;m.opacity=.7+.3*pulse;break;
 case 'chariot-wheel rotation':break;
 case 'manuscript opening':m.scale=.88+.12*q;break;
 case 'temple-door opening':break;
 case 'fabric unfolding':m.reveal=q;break;
 case 'drum vibration':m.scale=1+.015*power*Math.sin(p*Math.PI*8);break;
 case 'limited folk-figure wobble':m.rotate=1.2*power*s;break;
 case 'processional parallax':m.x=35*s*power;break;
 case 'mural-paint spread':m.scale=.3+.7*q;break;
 case 'scroll wipe':m.reveal=q;break;
 }
 m.scale*=1+Math.max(0,Math.min(1,beat))*.035*power;
 return m;
}
