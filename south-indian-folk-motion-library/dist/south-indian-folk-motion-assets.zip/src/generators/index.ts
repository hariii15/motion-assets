import {seeded, ease, clamp} from '../utils/random';
export type GeneratorProps={variant:string;progress?:number;primaryColor?:string;secondaryColor?:string;accentColor?:string;strokeWidth?:number;opacity?:number;scale?:number;rotation?:number;beatStrength?:number;intensity?:number;direction?:'left'|'right'|'up'|'down';seed?:number;durationInFrames?:number;glowAmount?:number;swayAmount?:number;loop?:boolean;exclusionZones?:{x:number;y:number;width:number;height:number}[]};
type C={p:number;a:string;b:string;c:string;cream:string;sw:number;seed:number;v:string;power:number;loop:boolean};
const tau=Math.PI*2;
const path=(d:string,fill='none',stroke='currentColor',extra='')=>`<path d="${d}" fill="${fill}" stroke="${stroke}" stroke-linecap="round" stroke-linejoin="round" ${extra}/>`;
const circle=(x:number,y:number,r:number,fill='none',stroke='currentColor',extra='')=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${fill}" stroke="${stroke}" ${extra}/>`;
const rect=(x:number,y:number,w:number,h:number,fill:string,rx=0)=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" fill="${fill}"/>`;
const group=(s:string,t:string,extra='')=>`<g transform="${t}" ${extra}>${s}</g>`;
const repeat=(n:number,fn:(i:number)=>string)=>Array.from({length:n},(_,i)=>fn(i)).join('');
const polar=(r:number,t:number)=>[500+r*Math.cos(t),500+r*Math.sin(t)];
const petal=(x:number,y:number,s:number,col:string,angle=0)=>group(path('M0 0 C-65 -65 -55 -135 0 -185 C55 -135 65 -65 0 0Z',col,'currentColor'),`translate(${x} ${y}) rotate(${angle}) scale(${s})`);
function flower(x:number,y:number,r:number,n:number,c:C,opening=1){return repeat(n,i=>petal(x,y,r/185,c.a,i*360/n+opening*5))+circle(x,y,r*.16,c.b,c.c);}
const leaf=(x:number,y:number,s:number,angle:number,c:C)=>group(path('M0 0 Q-100 -120 0 -250 Q100 -120 0 0Z',c.a,c.b)+path('M0 -12V-235 M0 -80L-43 -130 M0 -130L40 -175','none',c.b),`translate(${x} ${y}) rotate(${angle}) scale(${s})`);
const rings=(c:C)=>repeat(3,i=>circle(500,500,170+i*65,i===0?'none':'none',i%2?c.b:c.a,`stroke-width="${6-i}"`));
export function KolamBody(c:C):string{
 const v=c.v;
 if(v.includes('dot-grid'))return repeat(7,y=>repeat(7,x=>circle(260+x*80,260+y*80,6,c.a,'none')))+repeat(6,i=>path(`M${260+i*80} 230 Q${300+i*80} 195 ${340+i*80} 230`, 'none',c.b));
 if(v.includes('border')||v.includes('threshold')){
  let s=repeat(9,i=>group(path('M0 0C-45 -60 45 -60 0 0C-45 60 45 60 0 0','none',c.a)+circle(0,0,5,c.b,'none'),`translate(${180+i*80} 500)`));
  s+=path('M140 425H860M140 575H860','none',c.b);
  if(v.includes('threshold'))s+=group(s,'translate(0 150)')+group(s,'translate(0 -150)');
  return v.includes('vertical')?group(s,'rotate(90 500 500)'):s;
 }
 if(v.includes('grid'))return repeat(5,y=>repeat(5,x=>group(v.includes('flower')?flower(0,0,46,4,c):path('M0 -48L48 0L0 48L-48 0Z','none',c.a)+circle(0,0,4,c.b,'none'),`translate(${260+x*120} ${260+y*120}) ${v.includes('diamond')?'rotate(45)':''}`)));
 const n=v.includes('mandala')?16:v.includes('02')?10:12;
 let s=circle(500,500,235,'none',c.b)+circle(500,500,310,'none',c.a);
 s+=repeat(n,i=>group(path('M500 195C610 275 610 360 500 415C390 360 390 275 500 195Z','none',i%2?c.b:c.a)+circle(500,170,5,c.b,'none'),`rotate(${i*360/n} 500 500)`));
 if(!v.includes('frame'))s+=flower(500,500,125,8,{...c,a:'none'})+circle(500,500,26,'none',c.b);
 return s;
}
export function TamilBrushBody(c:C):string{
 // Non-linguistic stroke studies: intentionally disconnected, not font glyphs.
 const variants=[['M220 610C170 380 430 220 530 390C610 540 380 650 320 530C280 450 420 430 460 500','M570 300C750 310 840 520 650 640'],['M220 350C390 240 490 400 380 530C240 700 610 760 710 520','M570 280Q840 290 760 490'],['M210 600C270 240 700 230 780 450C850 660 580 720 470 570','M370 430Q490 350 550 420'],['M240 560C200 300 600 240 660 420C720 600 450 660 380 520','M560 590Q760 680 790 410'],['M240 330C520 260 690 340 580 500C450 660 240 610 290 460','M650 330Q810 470 710 650']];
 if(c.v.includes('inscription'))return repeat(6,y=>repeat(9,x=>path(`M${200+x*70} ${300+y*75}q18 -20 32 0q-10 24 10 30`,'none',y%2?c.b:c.a,'stroke-width="6"')));
 const ix=c.v.includes('02')?1:c.v.includes('curve')?2:c.v.includes('zha')?3:c.v.includes('ka')?4:0;
 return variants[ix].map((d,i)=>path(d,'none',i?c.b:c.a,`stroke-width="${i?16:26}"`)).join('')+path('M220 735Q500 690 770 715','none',c.c,'stroke-width="4"');
}
export function PalmLeafBody(c:C):string{
 if(c.v.includes('stone'))return rect(170,210,660,570,c.c,15)+rect(195,235,610,520,c.cream,7)+group(TamilBrushBody({...c,v:'inscription'}),'translate(0 10)');
 const open=.25+.75*ease(c.p);
 const folio=(y:number,angle:number)=>group(rect(160,y,680,94,c.cream,18)+path(`M185 ${y+15}H815M185 ${y+78}H815`,'none',c.b,'stroke-width="3"')+circle(235,y+47,9,c.c,'none')+circle(765,y+47,9,c.c,'none')+repeat(10,i=>path(`M${280+i*43} ${y+36}q8 -9 16 0m-16 18h25`,'none',c.a,'stroke-width="3"')),`rotate(${angle} 500 500)`);
 if(c.v.includes('writing'))return folio(452,0);
 return repeat(5,i=>folio(300+i*85,(i-2)*(c.v.includes('turn')?20:5)*open))+path('M235 330V690M765 330V690','none',c.b,'stroke-width="5"');
}
const wheel=(x:number,y:number,r:number,c:C)=>circle(x,y,r,c.c,c.b)+circle(x,y,r*.78,'none',c.a)+repeat(12,i=>group(path(`M${x} ${y-r*.7}V${y+r*.7}`,'none',c.b),`rotate(${i*30} ${x} ${y})`))+circle(x,y,r*.15,c.b,c.a);
const tower=(c:C)=>repeat(6,i=>{const w=570-i*68,y=740-i*88;return path(`M${500-w/2} ${y}h${w}l-18 -64H${518-w/2}Z`,i%2?c.a:c.c,c.b)+repeat(7-i,j=>rect(500-w/2+27+j*((w-54)/(7-i)),y-49,17,29,c.cream,5));})+path('M420 205Q500 120 580 205Z',c.b,c.a)+repeat(5,i=>circle(440+i*30,170-Math.sin(i/4*Math.PI)*20,7,c.b,'none'))+rect(456,650,88,90,c.a,40);
export function TempleArchitectureBody(c:C):string{
 const v=c.v;
 if(v.includes('wheel'))return group(wheel(500,500,285,c),`rotate(${c.p*360} 500 500)`);
 if(v.includes('gopuram'))return tower(c)+path('M180 760H820','none',c.b);
 if(v.includes('car-outline'))return group(tower(c),'translate(120 -15) scale(.76)')+rect(230,670,540,62,c.a,8)+wheel(330,755,72,c)+wheel(670,755,72,c)+path('M205 725H795','none',c.b);
 if(v.includes('bell'))return repeat(3,i=>{const x=300+i*200,y=340+(i%2)*100;return path(`M${x} 160V${y-45}`,'none',c.b)+group(path(`M${x-70} ${y+130}Q${x-45} ${y+90} ${x-45} ${y+15}Q${x} ${y-50} ${x+45} ${y+15}Q${x+45} ${y+90} ${x+70} ${y+130}Z`,c.b,c.a)+circle(x,y+140,14,c.a,c.c)+path(`M${x-65} ${y+115}h130`,'none',c.c),`rotate(${Math.sin(c.p*tau)*6*c.power} ${x} ${y-45})`);})+path('M200 160H800','none',c.a);
 if(v.includes('umbrella'))return path('M170 450Q500 110 830 450Z',c.a,c.b)+repeat(9,i=>path(`M500 260Q${220+i*70} 350 ${220+i*70} 450`,'none',c.b))+path('M170 460H830M500 460V790','none',c.b)+repeat(12,i=>circle(190+i*56,480,9,c.b,c.a));
 if(v.includes('sculpture'))return path('M470 280Q440 230 470 195Q500 165 530 195Q560 230 530 280L550 310Q610 340 620 440L670 510L650 535L580 470L555 390L550 530L585 740L535 770L505 565L480 770L430 770L455 530L440 385L395 475L350 510L330 490L375 435Q390 330 450 310Z',c.c,c.b)+path('M450 315Q500 355 550 315M455 515Q500 550 550 515','none',c.b)+rect(360,790,280,35,c.b,8);
 if(v.includes('pillar'))return rect(400,220,200,50,c.a,7)+rect(420,280,160,410,c.c,10)+repeat(6,i=>path(`M435 ${310+i*61}h130`,'none',c.b))+rect(385,700,230,60,c.a,6)+rect(365,775,270,35,c.b,5);
 if(v.includes('door')){
 const opening=ease(c.p),w=235*(1-opening*.9);
 return path('M200 800V310Q500 100 800 310V800','none',c.b,'stroke-width="22"')+rect(245,320,w,460,c.a,8)+rect(755-w,320,w,460,c.a,8)+repeat(6,i=>circle(265+w*.7,370+i*65,7,c.b,'none')+circle(735-w*.7,370+i*65,7,c.b,'none'))+path('M190 815H810','none',c.b);
 }
 if(v.includes('mandapam'))return path('M155 310L500 195L845 310Z',c.a,c.b)+rect(155,320,690,45,c.b)+repeat(4,i=>rect(205+i*175,365,65,390,c.c,5)+rect(190+i*175,720,95,40,c.a))+rect(150,775,700,35,c.b);
 return path('M185 795V420Q190 150 500 170Q810 150 815 420V795','none',c.a,'stroke-width="25"')+path('M235 795V420Q240 230 500 235Q760 230 765 420V795','none',c.b,'stroke-width="10"')+repeat(13,i=>{const [x,y]=polar(285,Math.PI+i*Math.PI/12);return circle(x,y+0,9,c.b,c.a);});
}
const lamp=(x:number,y:number,s:number,c:C)=>group(path('M-120 0Q0 115 120 0Z',c.b,c.a)+path('M0 65V135M-70 140H70','none',c.a,'stroke-width="13"')+group(path('M0 -15C-70 -65 -5 -105 0 -165C65 -95 65 -50 0 -15Z',c.b,c.a)+path('M0 -30Q-25 -60 0 -110Q28 -60 0 -30Z',c.cream,'none'),`rotate(${Math.sin(c.p*tau*3)*2*c.power} 0 -15) scale(${.92+.08*Math.sin(c.p*tau*2)})`),`translate(${x} ${y}) scale(${s})`);
export function SpiritualLightBody(c:C):string{
 const v=c.v;
 if(v==='aura-ring')return rings(c);
 if(v.includes('lamp-row'))return repeat(5,i=>lamp(210+i*145,550,.5,c));
 if(v.includes('lamp-single'))return lamp(500,535,1.8,c)+circle(500,430,275,'none',c.b,'stroke-width="2" stroke-dasharray="3 20"');
 if(v.includes('flame'))return group(path('M0 0C-120 -140 -10 -240 0 -370C140 -200 140 -90 0 0Z',c.b,c.a)+path('M0 -35Q-65 -125 0 -260Q70 -130 0 -35Z',c.cream,'none'),`translate(500 730) rotate(${Math.sin(c.p*tau*3)*2*c.power})`);
 if(v.includes('incense'))return path(`M420 800L505 570M470 575C300 470 675 430 490 315C370 240 590 180 550 155`,'none',c.a,'stroke-width="10"')+path('M505 600C650 460 400 430 580 300','none',c.b,'stroke-width="5" opacity=".6"');
 if(v.includes('lotus'))return flower(500,580,210,8,c)+path('M270 740H730M320 780H680','none',c.b,'stroke-width="20"');
 if(v.includes('particles'))return AtmosphericParticleBody({...c,v:'floating-gold-dust'});
 if(v.includes('rays'))return repeat(32,i=>group(path(`M500 290V${160+(i%3)*20}`,'none',i%2?c.b:c.a,`stroke-width="${i%2?4:12}" opacity=".45"`),`rotate(${i*11.25} 500 500)`))+circle(500,500,175,'none',c.b,'stroke-width="2"');
 return circle(500,500,250,'none',c.a)+circle(500,500,280,'none',c.b)+repeat(24,i=>group(path('M500 175Q475 150 500 115Q525 150 500 175Z',c.b,c.a)+circle(500,210,7,c.b,'none'),`rotate(${i*15} 500 500)`))+circle(500,500,220,'none',c.b,'stroke-dasharray="2 18"');
}
export function FlowerAndGarlandBody(c:C):string{
 const v=c.v;
 if(v.includes('leaf-pair'))return leaf(470,790,1.9,-28,c)+leaf(530,790,1.9,28,c);
 if(v.includes('toran'))return path('M150 250Q500 410 850 250','none',c.b)+repeat(11,i=>leaf(180+i*64,280+65*Math.sin(i/10*Math.PI),.63,(i-5)*3,c));
 if(v.includes('vine'))return path('M300 820C700 700 250 450 660 180','none',c.b)+repeat(8,i=>leaf(400+Math.sin(i)*80,730-i*70,.45,i%2?-65:70,c))+repeat(4,i=>flower(390+i*65,700-i*145,40,6,c));
 if(v.includes('garland'))return path('M160 240Q500 900 840 240','none',c.b)+repeat(29,i=>{const t=i/28,x=170+t*660,y=250+410*Math.sin(t*Math.PI);return flower(x,y,v.includes('jasmine')?25:32,v.includes('jasmine')?5:9,{...c,a:v.includes('jasmine')?c.cream:c.b});});
 if(v.includes('ring'))return repeat(16,i=>{const [x,y]=polar(280,i*tau/16);return flower(x,y,49,6,c);});
 if(v.includes('burst')||v.includes('stream')){const r=seeded(c.seed);return repeat(22,i=>{const t=r()*tau,rad=80+r()*240;const drift=c.loop?Math.sin(c.p*tau+i)*30:c.p*70;return petal(500+Math.cos(t)*rad,500+Math.sin(t)*rad+drift,.25+r()*.18,i%2?c.a:c.b,i*73+(c.loop?Math.sin(c.p*tau)*12:c.p*20));});}
 if(v.includes('lotus-petal'))return petal(500,720,2.4,c.a);
 const opening=.38+.62*ease(c.p);
 return repeat(7,i=>petal(500,675,1.7,c.a,(i-3)*22*opening))+repeat(5,i=>petal(500,715,1.25,c.b,(i-2)*30*opening))+path('M260 755Q500 830 740 755Q500 680 260 755Z',c.c,c.b);
}
function bird(c:C,fan=false):string{
 const feathers=repeat(11,i=>{const angle=(i-5)*14;return group(path('M500 650C440 510 425 250 500 175C575 250 560 510 500 650Z',i%2?c.a:c.c,c.b)+`<ellipse cx="500" cy="285" rx="22" ry="37" fill="${c.b}" stroke="${c.a}"/>`+circle(500,285,10,c.c,c.a),`rotate(${angle} 500 650)`);});
 return feathers+(fan?'':path('M420 660Q340 540 480 480Q560 450 565 360Q570 300 625 325Q670 355 620 390L610 530Q695 600 610 665Z',c.a,c.b)+path('M625 340L685 355L625 365',c.b,c.a)+path('M485 665L470 785M550 665L580 785M450 790H490M560 790H605','none',c.b)+circle(620,343,4,c.c,'none'));
}
function animal(kind:string,c:C):string{
 if(kind.includes('peacock')||kind.includes('fan'))return bird(c,kind.includes('fan'));
 if(kind.includes('fish'))return repeat(2,i=>group(path('M260 500Q450 315 640 500Q450 685 260 500ZM640 500L760 390V610Z',c.a,c.b)+path('M380 420Q450 500 380 580M440 405Q510 500 440 595','none',c.b)+circle(325,475,6,c.c,'none'),`rotate(${i*180} 500 500) translate(0 ${i?130:-130}) scale(.85) translate(90 90)`));
 if(kind.includes('annam')||kind.includes('rooster'))return path('M270 630Q170 420 420 460Q555 480 560 340Q540 250 600 235Q690 235 660 300L625 340L640 530Q720 650 550 700Z',c.a,c.b)+path('M300 550Q440 510 520 625Q390 710 300 550Z',c.c,c.b)+path('M645 260L720 285L650 300M480 695V795M550 695V795','none',c.b)+circle(630,263,5,c.c,'none')+(kind.includes('rooster')?path('M580 235Q530 150 600 185Q640 125 660 210',c.b,c.a):'');
 const ele=kind.includes('elephant'),bull=kind.includes('bull'),yali=kind.includes('yali');
 let s=path(ele?'M230 410Q230 330 370 340L620 355Q760 350 770 460L765 650Q730 720 695 645L700 495L650 480L650 750H580L560 600H390L365 750H290L280 510Z':'M245 480Q280 365 460 410L590 430L650 300L720 295L760 360L710 420L690 535L640 600L635 755H585L565 590L390 570L350 755H295L320 545Z',c.a,c.b);
 s+=path('M340 425Q470 385 575 445L560 555Q450 595 350 540Z',c.c,c.b)+repeat(5,i=>circle(375+i*39,483,7,c.b,'none'))+path('M250 465Q160 500 190 635','none',c.b)+circle(ele?730:710,ele?410:340,5,c.c,'none');
 if(ele)s+=path('M655 390Q570 370 610 500Q670 535 675 430Z',c.b,c.a)+path('M740 495Q820 525 795 455','none',c.cream,'stroke-width="12"');
 if(bull)s+=path('M650 320Q575 220 620 205Q625 270 680 290M710 295Q780 250 760 205Q820 245 740 340','none',c.b,'stroke-width="13"')+path('M395 410Q425 315 485 405',c.a,c.b);
 if(yali)s+=path('M680 345Q600 260 640 215Q710 270 720 310M720 400Q820 420 810 330Q860 405 780 475','none',c.b,'stroke-width="14"')+path('M590 415L570 360L535 410L495 360L470 410',c.b,c.a);
 if(!ele&&!bull&&!yali)s+=path('M650 300L645 240L680 295M580 420Q570 330 650 300','none',c.b,'stroke-width="17"');
 return s;
}
export function FolkAnimalBody(c:C):string{return c.v.includes('procession')?repeat(3,i=>group(animal(['elephant','horse','bull'][i],c),`translate(${i*245-20} ${270-i*12}) scale(.43)`)):animal(c.v,c);}
export function InstrumentBody(c:C):string{
 const v=c.v;
 if(v.includes('parai'))return circle(500,500,285,c.a,c.b)+circle(500,500,255,c.cream,c.c)+repeat(16,i=>{const [x,y]=polar(270,i*tau/16);return circle(x,y,7,c.b,c.c);})+path('M230 745L660 250M355 800L770 345','none',c.c,'stroke-width="14"');
 if(v.includes('nadaswaram'))return group(path('M465 200H535L550 630L620 770H380L450 630Z',c.c,c.b)+repeat(7,i=>circle(500,300+i*43,9,c.b,c.a))+path('M455 625H545M450 650H550M400 740H600','none',c.b), 'rotate(24 500 500)');
 if(v.includes('veena'))return group(circle(310,650,140,c.a,c.b)+path('M370 570L650 260L710 320L430 665Z',c.c,c.b)+circle(710,260,70,c.a,c.b)+repeat(4,i=>path(`M${300+i*12} 660L${680+i*6} 285`,'none',c.b,'stroke-width="2"'))+repeat(10,i=>path(`M${430+i*23} ${555-i*24}l35 32`,'none',c.cream,'stroke-width="3"')),'rotate(10 500 500)');
 if(v.includes('jalra'))return circle(355,500,170,c.b,c.a)+circle(645,500,170,c.b,c.a)+circle(355,500,48,c.a,c.c)+circle(645,500,48,c.a,c.c)+path('M355 500Q500 250 645 500','none',c.c);
 const barrel=v.includes('mridangam');return path(barrel?'M240 350Q500 230 760 350V650Q500 770 240 650Z':'M255 320Q500 285 745 320Q820 500 745 680Q500 715 255 680Q180 500 255 320Z',c.a,c.b)+repeat(11,i=>path(`M${260+i*48} 335L${285+i*43} 665`,'none',c.cream,'stroke-width="4"'))+`<ellipse cx="255" cy="500" rx="75" ry="175" fill="${c.cream}" stroke="${c.b}"/><ellipse cx="745" cy="500" rx="65" ry="175" fill="${c.cream}" stroke="${c.b}"/>`+`<ellipse cx="255" cy="500" rx="30" ry="75" fill="${c.c}"/>`;
}
export function RhythmBody(c:C):string{
 if(c.v.includes('ripple')||c.v.includes('pulse'))return rings(c);
 if(c.v.includes('wheel'))return wheel(500,500,280,c)+repeat(16,i=>{const[x,y]=polar(330,i*tau/16);return circle(x,y,8,c.a,c.b);});
 return path('M140 500'+repeat(18,i=>`Q${160+i*40} ${500+(i%2?1:-1)*(40+(i%5)*22)} ${180+i*40} 500`),'none',c.a,'stroke-width="12"')+path('M150 640H850M150 360H850','none',c.b,'stroke-dasharray="2 15"');
}
export function TextileBorderBody(c:C):string{
 const v=c.v;
 if(v.includes('block-print-flower'))return flower(500,500,255,8,c)+repeat(8,i=>{const[x,y]=polar(330,i*tau/8);return circle(x,y,10,c.b,'none');});
 if(v.includes('block-print-leaf'))return leaf(500,800,2.2,0,c);
 if(v.includes('checked'))return repeat(8,i=>rect(180+i*82,180,36,640,i%2?c.a:c.b)+rect(180,180+i*82,640,36,i%2?c.a:c.b));
 if(v.includes('diamond'))return repeat(5,y=>repeat(5,x=>group(path('M0 -45L45 0L0 45L-45 0Z',y%2?c.a:c.c,c.b)+circle(0,0,7,c.b,'none'),`translate(${260+x*120} ${260+y*120})`)));
 return path('M135 320H865M135 680H865','none',c.b,'stroke-width="13"')+repeat(12,i=>path(`M${140+i*60} 365l30 58l30 -58M${140+i*60} 635l30 -58l30 58`,v.includes('silk')?c.b:c.a,c.b))+rect(140,450,720,100,c.a)+repeat(12,i=>group(flower(0,0,20,6,{...c,a:c.b}),`translate(${170+i*60} 500)`));
}
export function PopPrintBody(c:C):string{
 const r=seeded(c.seed);
 if(c.v.includes('dots'))return repeat(12,y=>repeat(12,x=>circle(220+x*50+r()*3,220+y*50+r()*3,3+(x+y)%8,c.a,'none')));
 if(c.v.includes('shadow'))return group(flower(500,500,245,6,{...c,a:c.b}),'translate(17 15)')+flower(500,500,245,6,c);
 if(c.v.includes('arrow'))return path('M190 465Q430 430 650 450L590 335L820 500L590 665L650 550Q400 525 190 560Z',c.a,c.b)+path('M235 495Q430 480 625 495','none',c.b);
 if(c.v.includes('spark'))return repeat(8,i=>group(path('M500 430Q480 360 500 210Q520 360 500 430Z',i%2?c.a:c.b,'none'),`rotate(${i*45} 500 500)`))+circle(500,500,24,c.c,c.b);
 return circle(500,500,180,'none',c.a)+path('M500 180V820M180 500H820','none',c.b)+repeat(4,i=>group(path('M260 340V260H340','none',c.a,'stroke-width="14"'),`rotate(${i*90} 500 500)`));
}
export function AtmosphericParticleBody(c:C):string{
 const r=seeded(c.seed),v=c.v;
 if(v.includes('shadow'))return group(TempleArchitectureBody({...c,v:'mandapam-silhouette'}),'skewX(-8) translate(70 0)','opacity=".28"');
 return repeat(v.includes('orbs')||v.includes('glow')?12:65,i=>{const x=170+r()*660,y=170+r()*660,s=r(),phase=r()*tau;const drift=Math.sin(c.p*tau+phase)*25*c.power,xx=x+Math.cos(c.p*tau+phase)*12,yy=y+drift;
 if(v.includes('petal'))return petal(xx,yy,.08+s*.12,i%2?c.a:c.b,i*27+(c.loop?Math.sin(c.p*tau)*12:c.p*12));
 if(v.includes('confetti'))return group(rect(-4,-12,8,24,i%2?c.a:c.b,2),`translate(${xx} ${yy}) rotate(${i*37+(c.loop?Math.sin(c.p*tau)*12:c.p*20)})`);
 if(v.includes('orbs')||v.includes('glow'))return circle(xx,yy,18+s*45,c.b,'none',`opacity="${.06+s*.12}"`)+circle(xx,yy,5+s*10,c.cream,'none',`opacity=".2"`);
 return circle(xx,yy,1+s*4,i%2?c.b:c.cream,'none',`opacity="${.25+s*.6}"`);
 });
}
export function TransitionBody(c:C):string{
 const v=c.v,p=ease(c.p);
 if(v.includes('kolam'))return KolamBody({...c,v:'kolam-mandala'});
 if(v.includes('lotus'))return FlowerAndGarlandBody({...c,v:'lotus-bloom'});
 if(v.includes('petal'))return FlowerAndGarlandBody({...c,v:'petal-stream'});
 if(v.includes('garland'))return repeat(2,i=>group(FlowerAndGarlandBody({...c,v:'jasmine-garland'}),`translate(${(i?1:-1)*p*125} 0) translate(500 500) scale(.7) translate(-500 -500)`));
 if(v.includes('door'))return TempleArchitectureBody({...c,v:'temple-door-opening'});
 if(v.includes('palm'))return PalmLeafBody({...c,v:'palm-leaf-page-turn'});
 if(v.includes('textile'))return group(TextileBorderBody({...c,v:'silk-border'}),`translate(${(p-.5)*90} 0)`);
 if(v.includes('lamp'))return SpiritualLightBody({...c,v:'divine-light-rays-soft'});
 if(v.includes('incense'))return repeat(8,i=>group(SpiritualLightBody({...c,v:'incense-curve'}),`translate(${(i-4)*55} 0)`,'opacity=".22"'));
 if(v.includes('stamp'))return TextileBorderBody({...c,v:'block-print-flower'});
 if(v.includes('mural'))return repeat(14,i=>{const[x,y]=polar(180+(i%3)*50,i*tau/14);return circle(x,y,80+p*55,i%2?c.a:c.b,'none');});
 return rect(185,240,630,520,c.cream,9)+path('M235 300H765M235 700H765','none',c.b)+repeat(2,i=>group(rect(140,210,65,580,c.a,22)+path('M155 240V760','none',c.b),`translate(${i?655:0} 0)`))+KolamBody({...c,v:'kolam-border-horizontal'});
}
const bodies={KolamGenerator:KolamBody,TamilBrushGenerator:TamilBrushBody,TempleArchitectureGenerator:TempleArchitectureBody,PalmLeafGenerator:PalmLeafBody,SpiritualLightGenerator:SpiritualLightBody,FlowerAndGarlandGenerator:FlowerAndGarlandBody,FolkAnimalGenerator:FolkAnimalBody,InstrumentGenerator:InstrumentBody,TextileBorderGenerator:TextileBorderBody,PopPrintGenerator:PopPrintBody,RhythmGenerator:RhythmBody,TransitionGenerator:TransitionBody,AtmosphericParticleGenerator:AtmosphericParticleBody};
export type GeneratorName=keyof typeof bodies;
export function makeBody(name:GeneratorName,props:GeneratorProps){const p=clamp(props.progress??1);const c:C={p,a:props.primaryColor??'#C9342F',b:props.secondaryColor??'#D6A63A',c:props.accentColor??'#24305E',cream:'#F0D9A4',sw:props.strokeWidth??5,seed:props.seed??1,v:props.variant,power:props.intensity??.5,loop:props.loop??true};return bodies[name](c);}

export const KolamGenerator=(props:GeneratorProps)=>makeBody("KolamGenerator",props);
export const TamilBrushGenerator=(props:GeneratorProps)=>makeBody("TamilBrushGenerator",props);
export const TempleArchitectureGenerator=(props:GeneratorProps)=>makeBody("TempleArchitectureGenerator",props);
export const PalmLeafGenerator=(props:GeneratorProps)=>makeBody("PalmLeafGenerator",props);
export const SpiritualLightGenerator=(props:GeneratorProps)=>makeBody("SpiritualLightGenerator",props);
export const FlowerAndGarlandGenerator=(props:GeneratorProps)=>makeBody("FlowerAndGarlandGenerator",props);
export const FolkAnimalGenerator=(props:GeneratorProps)=>makeBody("FolkAnimalGenerator",props);
export const InstrumentGenerator=(props:GeneratorProps)=>makeBody("InstrumentGenerator",props);
export const TextileBorderGenerator=(props:GeneratorProps)=>makeBody("TextileBorderGenerator",props);
export const PopPrintGenerator=(props:GeneratorProps)=>makeBody("PopPrintGenerator",props);
export const RhythmGenerator=(props:GeneratorProps)=>makeBody("RhythmGenerator",props);
export const TransitionGenerator=(props:GeneratorProps)=>makeBody("TransitionGenerator",props);
export const AtmosphericParticleGenerator=(props:GeneratorProps)=>makeBody("AtmosphericParticleGenerator",props);
export const generators={KolamGenerator,TamilBrushGenerator,TempleArchitectureGenerator,PalmLeafGenerator,SpiritualLightGenerator,FlowerAndGarlandGenerator,FolkAnimalGenerator,InstrumentGenerator,TextileBorderGenerator,PopPrintGenerator,RhythmGenerator,TransitionGenerator,AtmosphericParticleGenerator};
