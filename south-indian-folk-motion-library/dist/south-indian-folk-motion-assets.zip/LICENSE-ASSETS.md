MIT License — Original procedural assets and library source

Copyright (c) 2026 motion-assets contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated original asset files (the "Materials"), to deal
in the Materials without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Materials, and to permit persons to whom the Materials are furnished
to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Materials.

THE MATERIALS ARE PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE MATERIALS OR THE USE OR OTHER DEALINGS IN THE
MATERIALS.

This license concerns original procedural outputs and source in this package.
Third-party software dependencies are not bundled in the asset archive and
remain subject to their own licenses. Cultural motifs are not claimed as
exclusive property. Cultural-use notes are contextual guidance and do not
claim ritual authority or historical authentication.
