# South Indian Folk Motion Library

102 original parametric ornaments, 13 generator families, 23 graceful motion presets and four intensity levels. This is a reusable asset pack, not a song edit. The library uses Tamil-first geometric, architectural, botanical and musical references without depicting specific deities or inventing Tamil words.

## Install and preview

Use the existing checkout in this isolated cloud environment; no additional worktree is necessary.

```sh
cd /workspace/motion-assets/south-indian-folk-motion-library
npm ci
npm run typecheck
npm run preview
```

Tested with Node 24.22.1, npm 11.9.0, TypeScript 5.9.2, React 19.1 and Remotion 4.0.387. Node 22 or newer is recommended. Raster export uses Sharp's bundled SVG renderer. Animated export requires `ffmpeg` and `ffprobe` with `libvpx-vp9`. Browser checks and composition renders use the existing `/usr/bin/chromium`; set `CHROMIUM_PATH` for preview rendering on other systems and adapt the browser-check executable if needed. Python 3 is used for strict XML validation. ZIP packaging uses the system `zip` and `unzip` commands. No cloud API, key, music, remote font or network service is needed after installation.

Open `exports/catalog/index.html` directly in a browser, or serve the **project directory** with `python3 -m http.server 8000` and visit `/exports/catalog/`. All catalog dependencies are local. Managed Chrome blocks `file:` navigation by policy; use the local HTTP server there. Browser checks run against a local-only HTTP server. The catalog includes downloads, cultural notes, pairing suggestions and a printable PDF generated using the already-installed Chromium.

## Export and regenerate

```sh
npm run export:svg
npx tsx scripts/export-png.ts --draft
npx tsx scripts/export-webm.ts --draft
# Inspect exports/previews/contact-sheet.png and the small draft WebMs first.
npm run export:png
npm run export:lottie
npm run export:webm
npm run catalog
npm run previews
npm run check:browser
npm run validate
npm run package
# All production steps in order:
npm run export:all
```

PNG and WebM scripts skip existing files to preserve successful outputs. After changing a generator, palette, manifest or timing, remove **only the affected** PNG, WebM and preview files before rerunning. SVG, Lottie and HTML are inexpensive and always rebuilt. No source dependency or lockfile is changed by export commands. A failed WebM remains a `.partial.webm`, and is never promoted to the final filename. FFmpeg receives a stream of PNG frames; no temporary frame directory is needed. The package script reruns validation and tests the ZIP's integrity.

Production stills: transparent SVG, viewBox `0 0 1000 1000`, and transparent 1024 × 1024 PNG. Priority motion: 512 × 512, 30fps, 90 frames / 3 seconds, VP9 with alpha. 20 priority assets each have a primary export; three looping kolam assets additionally have `-one-shot.webm` draw-on versions. Default behaviour and versions are recorded in `manifests/assets.json`. All 102 assets animate through source; the other 82 intentionally have no pre-rendered WebM.

## React, SVG and Remotion

`src/components/Asset.tsx` supplies a plain React `Asset`, a frame-aware `RemotionAsset`, and `renderSvg` for non-browser exports. `src/generators/index.ts` supplies all 13 named generators as parametric SVG markup functions. `makeBody` dispatches a family by name. Asset configurations, rather than duplicate component implementations, define the 102 forms.

```tsx
import {AbsoluteFill} from 'remotion';
import {RemotionAsset, Asset} from './src';

export const Ornament = () => (
  <AbsoluteFill>
    <RemotionAsset
      id="jasmine-garland"
      primaryColor="#13706D"
      secondaryColor="#D6A63A"
      accentColor="#24305E"
      durationInFrames={120}
      intensityName="ambient"
      exclusionZones={[{x:180,y:720,width:640,height:180}]}
    />
  </AbsoluteFill>
);
// Plain React, controlled by your own frame counter:
const WebOrnament = ({frame}: {frame:number}) =>
  <Asset id="kolam-mandala" frame={frame} durationInFrames={90} />;
```

Import the source into a TypeScript/React project with the dependencies in `package.json`. Keep `manifests/` beside `src/` because catalog configurations are imported at build time. Use the exported composition entry `src/demo/index.ts` in Remotion Studio. `AssetCatalogComposition` pages through all filenames by groups; `MotionGalleryComposition` covers all 23 motion presets; `LayeredDemoComposition` is a 1080 × 1440, two-second depth study with a neutral figure and a marked lyric-safe area. Catalog and motion-gallery MP4 previews render at half scale for efficient review; the layered demo renders at its native resolution. No audio is required or included.

## Recolour, duration and beat timing

The nine named colour constants are in `src/palettes/index.ts`; manifests use four-colour selections. Override `primaryColor`, `secondaryColor` and `accentColor` using CSS hex values. Sandalwood cream remains the neutral fourth ink inside relevant forms. Override the shared cream constant in the generator when a fully custom neutral is needed. Use three to five colours per composition.

`durationInFrames` changes the full motion length. `progress` overrides time explicitly in the interval 0–1; `static` gives a fully formed still. Frame calculations are deterministic. All random placement uses an integer `seed`; the same props and frame reproduce identical geometry. No wall clock or uncontrolled random calls are used.

Synchronize with a beat by passing the elapsed frames since its start and a decaying `beatStrength` value. For a 120BPM track at 30fps, quarter notes occur every 15 frames:

```tsx
const elapsed = frame % 15;
<Asset id="parai-drum" frame={elapsed} durationInFrames={15}
  beatStrength={Math.exp(-elapsed / 4)} intensityName="downbeat" />
```

Available intensity names: `ambient`, `secondary beat`, `downbeat`, `transition` (0.25, 0.5, 0.75, 1). Numeric `intensity` overrides these; `beatStrength` ranges 0–1. Additional controls include `variant`, `strokeWidth`, `opacity`, `scale`, `rotation`, `direction`, `glowAmount`, `swayAmount`, `loop`, and `exclusionZones`. Direction controls reveal origin. Zones use viewBox coordinates and preserve transparent openings for faces and lyrics. Explicit scales/rotations may require larger composition padding; validation checks shipped defaults. Use a unique `instanceId` for direct `renderSvg` strings embedded repeatedly in one DOM.

## Editors and layering

Import PNGs as transparent stills into Resolve, Premiere Pro or After Effects. SVGs remain editable in vector tools and web projects; editor support for direct SVG import varies. Place exported motion above the main footage and select straight/unmatted alpha if asked. The WebM frames are square ornaments with safe padding; scale them inside your project composition.

**VP9 alpha import varies by application and version.** WebM works in browsers and supporting editors/plugins; Premiere, Resolve and After Effects builds may require a WebM importer or conversion. For native editing, convert while preserving alpha using the explicit VP9 decoder:

```sh
ffmpeg -c:v libvpx-vp9 -i exports/webm/jasmine-garland.webm \
  -c:v prores_ks -profile:v 4 -pix_fmt yuva444p10le jasmine-garland-prores4444.mov
```

ProRes conversions are not bundled. Avoid converters that flatten to an opaque background. Looping clips have matching first/last visual states; one-shots hold their completed state in your timeline. Transition assets are transparent ornamental overlays. Use their alpha as a matte or drive the source's reveal progress when changing scenes; they do not automatically replace the underlying footage. No final edit, footage, music or lyrics are included.

## Lottie subset

Three exact concentric-circle animations are provided: `aura-ring`, `drum-skin-ripple`, `percussion-pulse`. Their circle geometry, strokes, scale and opacity are sampled from the same motion functions as SVG. Browser validation compares alpha against the SVG renderer at frames 0, 45 and 89. They use no SVG filter or matte approximation. Other forms use compound ornament, reveal masks or local deformation; `lottieCompatible: false` and a concrete exporter limitation are recorded rather than supplying misleading JSON. Those source animations remain usable in Remotion.

## Cultural use and limitations

Read `manifests/cultural-notes.json` and each asset's context/use notes. The designs are original interpretations, not transcriptions of historical art, exact kolam diagrams or technical instrument drawings. Regional, community and ceremonial practices are diverse. Consult a knowledgeable Tamil cultural practitioner for ritual, institutional or heritage-specific use.

Tamil brush assets and inscription lines contain non-linguistic fragments only. Names such as `tamil-letter-zha-abstract` indicate a gesture study, not a correct glyph or word. Add readable Tamil from user-supplied content and check its spelling and typography separately. Sculpture is a non-deity human study; the yali-inspired guardian is an interpretive architectural form. Do not label either as a documented sacred icon. Avoid demeaning placement, culturally incompatible montage or claims of historical authenticity. Parai is a living instrument with specific community and social histories.

The library deliberately uses limited flat inks with fine line work. Print imperfection is restrained and procedural; there are no raster textures or copied artworks. Botanical, animal and heritage silhouettes are schematic; the tiny cream components should be reviewed against pale backgrounds. WebM uses lossy colour compression while retaining alpha; SVG/PNG are the master stills. No external cultural expert review or real-editor import test is claimed. See the local validation report for checks actually executed.

## Files and verification

- `manifests/assets.json`: all 102 IDs, families, formats, cultural notes and motion metadata.
- `manifests/animations.json`: shared presets and intensities.
- `exports/catalog/`: browser catalog and print PDF.
- `exports/previews/`: draft stills, contact sheet, draft motions, three composition MP4s and validation evidence.
- `scripts/validate-assets.ts`: strict XML/JSON, IDs, safe paths, alpha, raster dimensions, out-of-bounds geometry, meaningful animation, loops, decoded VP9 alpha, frame counts, catalog and Lottie evidence.
- `dist/south-indian-folk-motion-assets.zip`: portable bundle, excluding dependencies, cache, browser binaries and temporary frames.

`LICENSE-ASSETS.md` grants use, modification and redistribution of the original procedural assets and source. Dependencies retain their respective licenses. No copyrighted soundtrack, third-party artwork or external font is distributed.
